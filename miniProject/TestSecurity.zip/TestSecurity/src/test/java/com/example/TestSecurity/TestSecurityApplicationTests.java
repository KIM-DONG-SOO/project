package com.example.TestSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
